using System;

namespace MultiTenancyServer.Samples.AspNetIdentityAndEFCore.Models
{
    public class ErrorViewModel
    {
        public string RequestId { get; set; }

        public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);
    }
}
