﻿namespace BotYoutube.Manager.Link
{
    partial class UpdateLink
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bTextbox1 = new BotYoutube.UI.Controls.BTextbox();
            this.label1 = new System.Windows.Forms.Label();
            this.bCheckBox1 = new BotYoutube.UI.Controls.BCheckBox();
            this.bCheckBox2 = new BotYoutube.UI.Controls.BCheckBox();
            this.bCheckBox3 = new BotYoutube.UI.Controls.BCheckBox();
            this.bCheckBox4 = new BotYoutube.UI.Controls.BCheckBox();
            this.bCheckBox5 = new BotYoutube.UI.Controls.BCheckBox();
            this.bNumericUpDown1 = new BotYoutube.UI.Controls.BNumericUpDown();
            this.bNumericUpDown2 = new BotYoutube.UI.Controls.BNumericUpDown();
            this.bNumericUpDown3 = new BotYoutube.UI.Controls.BNumericUpDown();
            this.bNumericUpDown4 = new BotYoutube.UI.Controls.BNumericUpDown();
            this.bNumericUpDown5 = new BotYoutube.UI.Controls.BNumericUpDown();
            this.bNumericUpDown6 = new BotYoutube.UI.Controls.BNumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.bNumericUpDown7 = new BotYoutube.UI.Controls.BNumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.bCheckBox6 = new BotYoutube.UI.Controls.BCheckBox();
            this.panEditer.SuspendLayout();
            this.pnMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bNumericUpDown1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bNumericUpDown2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bNumericUpDown3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bNumericUpDown4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bNumericUpDown5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bNumericUpDown6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bNumericUpDown7)).BeginInit();
            this.SuspendLayout();
            // 
            // panEditer
            // 
            this.panEditer.Controls.Add(this.bCheckBox6);
            this.panEditer.Controls.Add(this.label8);
            this.panEditer.Controls.Add(this.label7);
            this.panEditer.Controls.Add(this.label6);
            this.panEditer.Controls.Add(this.label5);
            this.panEditer.Controls.Add(this.label4);
            this.panEditer.Controls.Add(this.label3);
            this.panEditer.Controls.Add(this.bNumericUpDown7);
            this.panEditer.Controls.Add(this.label2);
            this.panEditer.Controls.Add(this.bNumericUpDown6);
            this.panEditer.Controls.Add(this.bNumericUpDown5);
            this.panEditer.Controls.Add(this.bNumericUpDown4);
            this.panEditer.Controls.Add(this.bNumericUpDown3);
            this.panEditer.Controls.Add(this.bNumericUpDown2);
            this.panEditer.Controls.Add(this.bNumericUpDown1);
            this.panEditer.Controls.Add(this.bCheckBox5);
            this.panEditer.Controls.Add(this.bCheckBox4);
            this.panEditer.Controls.Add(this.bCheckBox3);
            this.panEditer.Controls.Add(this.bCheckBox2);
            this.panEditer.Controls.Add(this.bCheckBox1);
            this.panEditer.Controls.Add(this.label1);
            this.panEditer.Controls.Add(this.bTextbox1);
            this.panEditer.Size = new System.Drawing.Size(561, 382);
            // 
            // pnMain
            // 
            this.pnMain.Size = new System.Drawing.Size(561, 462);
            // 
            // bTextbox1
            // 
            this.bTextbox1.KeyCommand = System.Windows.Forms.Keys.None;
            this.bTextbox1.Location = new System.Drawing.Point(106, 41);
            this.bTextbox1.Name = "bTextbox1";
            this.bTextbox1.Size = new System.Drawing.Size(334, 33);
            this.bTextbox1.TabIndex = 0;
            this.bTextbox1.Tag = "link";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(49, 45);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 25);
            this.label1.TabIndex = 1;
            this.label1.Text = "Link";
            // 
            // bCheckBox1
            // 
            this.bCheckBox1.AutoSize = true;
            this.bCheckBox1.Location = new System.Drawing.Point(106, 82);
            this.bCheckBox1.Name = "bCheckBox1";
            this.bCheckBox1.Size = new System.Drawing.Size(86, 29);
            this.bCheckBox1.TabIndex = 2;
            this.bCheckBox1.Tag = "IsView";
            this.bCheckBox1.Text = "View";
            this.bCheckBox1.UseVisualStyleBackColor = true;
            // 
            // bCheckBox2
            // 
            this.bCheckBox2.AutoSize = true;
            this.bCheckBox2.Location = new System.Drawing.Point(106, 121);
            this.bCheckBox2.Name = "bCheckBox2";
            this.bCheckBox2.Size = new System.Drawing.Size(75, 29);
            this.bCheckBox2.TabIndex = 3;
            this.bCheckBox2.Tag = "IsSub";
            this.bCheckBox2.Text = "Sub";
            this.bCheckBox2.UseVisualStyleBackColor = true;
            // 
            // bCheckBox3
            // 
            this.bCheckBox3.AutoSize = true;
            this.bCheckBox3.Location = new System.Drawing.Point(106, 160);
            this.bCheckBox3.Name = "bCheckBox3";
            this.bCheckBox3.Size = new System.Drawing.Size(77, 29);
            this.bCheckBox3.TabIndex = 4;
            this.bCheckBox3.Tag = "IsLike";
            this.bCheckBox3.Text = "Like";
            this.bCheckBox3.UseVisualStyleBackColor = true;
            // 
            // bCheckBox4
            // 
            this.bCheckBox4.AutoSize = true;
            this.bCheckBox4.Location = new System.Drawing.Point(106, 199);
            this.bCheckBox4.Name = "bCheckBox4";
            this.bCheckBox4.Size = new System.Drawing.Size(107, 29);
            this.bCheckBox4.TabIndex = 5;
            this.bCheckBox4.Tag = "IsDisLike";
            this.bCheckBox4.Text = "DisLike";
            this.bCheckBox4.UseVisualStyleBackColor = true;
            // 
            // bCheckBox5
            // 
            this.bCheckBox5.AutoSize = true;
            this.bCheckBox5.Location = new System.Drawing.Point(106, 238);
            this.bCheckBox5.Name = "bCheckBox5";
            this.bCheckBox5.Size = new System.Drawing.Size(133, 29);
            this.bCheckBox5.TabIndex = 6;
            this.bCheckBox5.Tag = "IsComment";
            this.bCheckBox5.Text = "Comment";
            this.bCheckBox5.UseVisualStyleBackColor = true;
            // 
            // bNumericUpDown1
            // 
            this.bNumericUpDown1.Location = new System.Drawing.Point(261, 80);
            this.bNumericUpDown1.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.bNumericUpDown1.Name = "bNumericUpDown1";
            this.bNumericUpDown1.Size = new System.Drawing.Size(179, 33);
            this.bNumericUpDown1.TabIndex = 7;
            this.bNumericUpDown1.Tag = "DelayView";
            this.bNumericUpDown1.Value = new decimal(new int[] {
            50000,
            0,
            0,
            0});
            // 
            // bNumericUpDown2
            // 
            this.bNumericUpDown2.Location = new System.Drawing.Point(261, 119);
            this.bNumericUpDown2.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.bNumericUpDown2.Name = "bNumericUpDown2";
            this.bNumericUpDown2.Size = new System.Drawing.Size(179, 33);
            this.bNumericUpDown2.TabIndex = 8;
            this.bNumericUpDown2.Tag = "DelaySub";
            this.bNumericUpDown2.Value = new decimal(new int[] {
            5000,
            0,
            0,
            0});
            // 
            // bNumericUpDown3
            // 
            this.bNumericUpDown3.Location = new System.Drawing.Point(261, 158);
            this.bNumericUpDown3.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.bNumericUpDown3.Name = "bNumericUpDown3";
            this.bNumericUpDown3.Size = new System.Drawing.Size(179, 33);
            this.bNumericUpDown3.TabIndex = 9;
            this.bNumericUpDown3.Tag = "DelayLike";
            this.bNumericUpDown3.Value = new decimal(new int[] {
            5000,
            0,
            0,
            0});
            // 
            // bNumericUpDown4
            // 
            this.bNumericUpDown4.Location = new System.Drawing.Point(261, 197);
            this.bNumericUpDown4.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.bNumericUpDown4.Name = "bNumericUpDown4";
            this.bNumericUpDown4.Size = new System.Drawing.Size(179, 33);
            this.bNumericUpDown4.TabIndex = 10;
            this.bNumericUpDown4.Tag = "DelayDisLike";
            this.bNumericUpDown4.Value = new decimal(new int[] {
            5000,
            0,
            0,
            0});
            // 
            // bNumericUpDown5
            // 
            this.bNumericUpDown5.Location = new System.Drawing.Point(261, 236);
            this.bNumericUpDown5.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.bNumericUpDown5.Name = "bNumericUpDown5";
            this.bNumericUpDown5.Size = new System.Drawing.Size(179, 33);
            this.bNumericUpDown5.TabIndex = 11;
            this.bNumericUpDown5.Tag = "DelayComment";
            this.bNumericUpDown5.Value = new decimal(new int[] {
            5000,
            0,
            0,
            0});
            // 
            // bNumericUpDown6
            // 
            this.bNumericUpDown6.Location = new System.Drawing.Point(261, 275);
            this.bNumericUpDown6.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.bNumericUpDown6.Name = "bNumericUpDown6";
            this.bNumericUpDown6.Size = new System.Drawing.Size(179, 33);
            this.bNumericUpDown6.TabIndex = 12;
            this.bNumericUpDown6.Tag = "DelayComment";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(178, 275);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 25);
            this.label2.TabIndex = 13;
            this.label2.Text = "Rank";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(109, 312);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(130, 25);
            this.label3.TabIndex = 15;
            this.label3.Text = "Target View";
            // 
            // bNumericUpDown7
            // 
            this.bNumericUpDown7.Location = new System.Drawing.Point(261, 314);
            this.bNumericUpDown7.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.bNumericUpDown7.Name = "bNumericUpDown7";
            this.bNumericUpDown7.Size = new System.Drawing.Size(179, 33);
            this.bNumericUpDown7.TabIndex = 14;
            this.bNumericUpDown7.Tag = "TargetView";
            this.bNumericUpDown7.Value = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(446, 83);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(102, 25);
            this.label4.TabIndex = 16;
            this.label4.Text = "Delay (s)";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(446, 122);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(102, 25);
            this.label5.TabIndex = 17;
            this.label5.Text = "Delay (s)";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(446, 164);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(102, 25);
            this.label6.TabIndex = 18;
            this.label6.Text = "Delay (s)";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(446, 200);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(102, 25);
            this.label7.TabIndex = 19;
            this.label7.Text = "Delay (s)";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(446, 242);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(102, 25);
            this.label8.TabIndex = 20;
            this.label8.Text = "Delay (s)";
            // 
            // bCheckBox6
            // 
            this.bCheckBox6.AutoSize = true;
            this.bCheckBox6.Location = new System.Drawing.Point(446, 42);
            this.bCheckBox6.Name = "bCheckBox6";
            this.bCheckBox6.Size = new System.Drawing.Size(98, 29);
            this.bCheckBox6.TabIndex = 21;
            this.bCheckBox6.Tag = "IsActive";
            this.bCheckBox6.Text = "Active";
            this.bCheckBox6.UseVisualStyleBackColor = true;
            // 
            // UpdateLink
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(563, 514);
            this.HideButtuonClose = true;
            this.HideButtuonMin = true;
            this.Name = "UpdateLink";
            this.Text = "Link Info";
            this.panEditer.ResumeLayout(false);
            this.panEditer.PerformLayout();
            this.pnMain.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.bNumericUpDown1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bNumericUpDown2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bNumericUpDown3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bNumericUpDown4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bNumericUpDown5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bNumericUpDown6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bNumericUpDown7)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private UI.Controls.BTextbox bTextbox1;
        private UI.Controls.BCheckBox bCheckBox1;
        private UI.Controls.BCheckBox bCheckBox2;
        private UI.Controls.BCheckBox bCheckBox3;
        private UI.Controls.BCheckBox bCheckBox4;
        private UI.Controls.BCheckBox bCheckBox5;
        private UI.Controls.BNumericUpDown bNumericUpDown1;
        private UI.Controls.BNumericUpDown bNumericUpDown5;
        private UI.Controls.BNumericUpDown bNumericUpDown4;
        private UI.Controls.BNumericUpDown bNumericUpDown3;
        private UI.Controls.BNumericUpDown bNumericUpDown2;
        private UI.Controls.BNumericUpDown bNumericUpDown6;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private UI.Controls.BNumericUpDown bNumericUpDown7;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private UI.Controls.BCheckBox bCheckBox6;
    }
}