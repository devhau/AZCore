﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BotYoutube.Database
{
    public interface IDBCreate
    {
        void CheckDatabase();
    }
}
