﻿namespace AZERP.Web.Permissions
{
    public partial class Permission
    {
        protected const string Group_Common= "Common";
        protected const int Group_Common_Index = 1;
        protected const string Group_Human_Resources = "Human Resources";
        protected const int Group_Human_Resources_Index = 2;
        protected const string Group_Sales = "Sales";
        protected const int Group_Sales_Index = 3;
        protected const string Group_Hotel = "Hotel";
        protected const int Group_Hotel_Index = 4;
    }
}
